import { joinRoom } from 'https://esm.run/trystero'

// ---------- DOM ----------
const joinScreen   = document.getElementById('join-screen')
const chatScreen   = document.getElementById('chat-screen')
const joinForm     = document.getElementById('join-form')
const nicknameInput = document.getElementById('nickname')
const roomInput    = document.getElementById('room-name')
const messagesEl   = document.getElementById('messages')
const messageForm  = document.getElementById('message-form')
const messageInput = document.getElementById('message-input')
const sendBtn      = document.getElementById('send-btn')
const leaveBtn     = document.getElementById('leave-btn')
const roomBadge    = document.getElementById('room-badge')
const peerCountEl  = document.getElementById('peer-count')

// ---------- State ----------
let room = null
let myName = 'Anonymous'
let peers = new Map() // peerId → name

// ---------- Helpers ----------
function showScreen(screen) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'))
  screen.classList.add('active')
}

function addMessage({ text, author, isOwn = false, isSystem = false }) {
  const div = document.createElement('div')
  div.className = 'message' + (isOwn ? ' own' : '') + (isSystem ? ' system' : '')

  if (isSystem) {
    div.innerHTML = `<div class="message-bubble">${escapeHtml(text)}</div>`
  } else {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    div.innerHTML = `
      <div class="message-meta">
        <span class="message-author">${escapeHtml(author)}</span>
        <span>${time}</span>
      </div>
      <div class="message-bubble">${escapeHtml(text)}</div>
    `
  }

  messagesEl.appendChild(div)
  messagesEl.scrollTop = messagesEl.scrollHeight
}

function escapeHtml(str) {
  const div = document.createElement('div')
  div.textContent = str
  return div.innerHTML
}

function updatePeerCount() {
  const count = peers.size + 1 // include self
  peerCountEl.textContent = `${count} online`
}

function sanitizeRoomName(name) {
  return name.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '').slice(0, 32) || 'general'
}

// ---------- Join ----------
joinForm.addEventListener('submit', async (e) => {
  e.preventDefault()

  myName = nicknameInput.value.trim() || 'Anonymous'
  const roomName = sanitizeRoomName(roomInput.value)

  roomBadge.textContent = `#${roomName}`
  messagesEl.innerHTML = ''
  peers.clear()
  updatePeerCount()

  // Unique appId so different sites don't collide
  const config = { appId: 'github-pages-p2p-chat-v1' }
  room = joinRoom(config, roomName)

  // Actions
  const [sendChat, getChat] = room.makeAction('chat')
  const [sendName, getName] = room.makeAction('name')

  // Announce our name
  sendName(myName)

  // Receive names
  getName((name, peerId) => {
    peers.set(peerId, name)
    updatePeerCount()
  })

  // Receive chat messages
  getChat(({ text, author }, peerId) => {
    addMessage({ text, author: author || peers.get(peerId) || 'Someone' })
  })

  // Peer events
  room.onPeerJoin(peerId => {
    // Tell the new peer our name
    sendName(myName, peerId)
    addMessage({ text: 'Someone joined the room', isSystem: true })
    updatePeerCount()
  })

  room.onPeerLeave(peerId => {
    const name = peers.get(peerId) || 'Someone'
    peers.delete(peerId)
    addMessage({ text: `${name} left the room`, isSystem: true })
    updatePeerCount()
  })

  // Store send function for the form
  window.__sendChat = (text) => {
    sendChat({ text, author: myName })
    addMessage({ text, author: myName, isOwn: true })
  }

  showScreen(chatScreen)
  messageInput.focus()

  addMessage({ text: `You joined #${roomName}`, isSystem: true })
  addMessage({
    text: 'Messages are peer-to-peer. Open this page in another tab or share the link with friends using the same room name.',
    isSystem: true
  })
})

// ---------- Send message ----------
messageForm.addEventListener('submit', (e) => {
  e.preventDefault()
  const text = messageInput.value.trim()
  if (!text || !window.__sendChat) return

  window.__sendChat(text)
  messageInput.value = ''
  messageInput.focus()
})

// ---------- Leave ----------
leaveBtn.addEventListener('click', () => {
  if (room) {
    room.leave()
    room = null
  }
  peers.clear()
  window.__sendChat = null
  showScreen(joinScreen)
  nicknameInput.focus()
})

// Focus nickname on load
nicknameInput.focus()
