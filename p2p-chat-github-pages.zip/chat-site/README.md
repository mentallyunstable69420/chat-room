# P2P Chat — GitHub Pages Chat Room

A fully **serverless**, **peer-to-peer** chat room that runs on GitHub Pages.

- No backend
- No accounts
- No API keys
- Messages travel directly between browsers via WebRTC
- Ephemeral (nothing is stored on any server)

Powered by [Trystero](https://github.com/dmotz/trystero) (Nostr strategy for peer discovery).

## Live Demo

After you deploy, your site will be at:

```
https://<your-username>.github.io/<repo-name>/
```

## Deploy to GitHub Pages (2 minutes)

### 1. Create a new repository

1. Go to [github.com/new](https://github.com/new)
2. Name it anything (e.g. `chat` or `p2p-chat`)
3. Make it **Public**
4. Do **not** initialize with a README
5. Click **Create repository**

### 2. Upload these files

You can either:

**Option A – Upload via the website**
1. On the new empty repo page click **uploading an existing file**
2. Drag the three files (`index.html`, `styles.css`, `app.js`) into the browser
3. Commit

**Option B – Git CLI**
```bash
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>
# copy index.html, styles.css, app.js into this folder
git add .
git commit -m "Add P2P chat"
git push origin main
```

### 3. Enable GitHub Pages

1. Go to your repo → **Settings** → **Pages**
2. Under **Source** choose **Deploy from a branch**
3. Branch: `main` / folder: `/ (root)`
4. Click **Save**

After ~30–60 seconds your site will be live at:

```
https://<your-username>.github.io/<repo-name>/
```

## How to use

1. Open the site
2. Enter a nickname
3. Enter a room name (or keep `general`)
4. Click **Join Room**
5. Share the same room name with friends — they will connect automatically

Open the page in two browser tabs to test it yourself.

## Features

- Real-time messaging
- Peer join / leave notifications
- Online counter
- Mobile-friendly
- Dark modern UI
- No data ever leaves the browsers of the people in the room

## Technical notes

- Uses Trystero’s Nostr strategy for peer discovery (public relays)
- Once connected, all messages go over encrypted WebRTC data channels
- Works behind most NATs; a public TURN server is used only when direct connection fails
- Completely free and open-source

## Customization

- Change the default room in `index.html` (`value="general"`)
- Change colors in `styles.css` (CSS variables at the top)
- Change the `appId` in `app.js` if you want completely isolated rooms from other instances of this chat

Enjoy chatting!
